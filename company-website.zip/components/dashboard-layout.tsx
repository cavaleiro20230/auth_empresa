import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { logout } from "@/lib/auth"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="font-bold">
              CompanyName
            </Link>
            <nav className="hidden md:flex gap-6">
              <Link href="/dashboard" className="text-sm font-medium">
                Dashboard
              </Link>
              <Link href="/dashboard/customers" className="text-sm font-medium">
                Customers
              </Link>
              <Link href="/dashboard/products" className="text-sm font-medium">
                Products
              </Link>
              <Link href="/dashboard/settings" className="text-sm font-medium">
                Settings
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <form action={logout}>
              <Button variant="outline" size="sm">
                Logout
              </Button>
            </form>
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
    </div>
  )
}

